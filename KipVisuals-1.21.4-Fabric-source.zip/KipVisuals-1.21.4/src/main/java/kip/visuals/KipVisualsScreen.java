package kip.visuals;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public final class KipVisualsScreen extends Screen {
    private static final int PANEL = 0xE8171722;
    private static final int PURPLE = 0xFF9B65FF;

    public KipVisualsScreen() {
        super(Text.literal("Kip Visuals"));
    }

    @Override
    protected void init() {
        int cx = width / 2;
        int y = height / 2 - 62;
        int w = 190;
        int x = cx - w / 2;

        addDrawableChild(ButtonWidget.builder(toggleText("Hit Sound", KipVisualsClient.hitSound), b -> {
            KipVisualsClient.hitSound = !KipVisualsClient.hitSound;
            b.setMessage(toggleText("Hit Sound", KipVisualsClient.hitSound));
        }).dimensions(x, y, w, 20).build());

        addDrawableChild(ButtonWidget.builder(toggleText("Hit Effect", KipVisualsClient.hitEffect), b -> {
            KipVisualsClient.hitEffect = !KipVisualsClient.hitEffect;
            b.setMessage(toggleText("Hit Effect", KipVisualsClient.hitEffect));
        }).dimensions(x, y + 25, w, 20).build());

        addDrawableChild(ButtonWidget.builder(toggleText("Custom Hitboxes", KipVisualsClient.customHitboxes), b -> {
            KipVisualsClient.customHitboxes = !KipVisualsClient.customHitboxes;
            b.setMessage(toggleText("Custom Hitboxes", KipVisualsClient.customHitboxes));
        }).dimensions(x, y + 50, w, 20).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Hitbox size: " +
                String.format("%.1f", KipVisualsClient.hitboxExpansion)), b -> {
            KipVisualsClient.hitboxExpansion = Math.min(2.0, KipVisualsClient.hitboxExpansion + 0.1);
            b.setMessage(Text.literal("Hitbox size: " +
                    String.format("%.1f", KipVisualsClient.hitboxExpansion)));
        }).dimensions(x, y + 75, w, 20).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Close"), b -> close())
                .dimensions(x, y + 103, w, 20).build());
    }

    private static Text toggleText(String name, boolean enabled) {
        return Text.literal(name + ": " + (enabled ? "ON" : "OFF"));
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context, mouseX, mouseY, delta);
        int cx = width / 2;
        int top = height / 2 - 91;
        context.fill(cx - 112, top, cx + 112, top + 190, PANEL);
        context.fill(cx - 112, top, cx + 112, top + 2, PURPLE);
        context.drawCenteredTextWithShadow(textRenderer, "Kip Visuals", cx, top + 9, 0xFFFFFFFF);
        context.drawCenteredTextWithShadow(textRenderer, "↑ / ↓  Hitbox size", cx, top + 169, 0xFFB9A6D8);
        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
