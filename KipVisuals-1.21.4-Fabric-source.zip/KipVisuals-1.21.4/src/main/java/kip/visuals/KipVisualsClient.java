package kip.visuals;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import org.lwjgl.glfw.GLFW;

public final class KipVisualsClient implements ClientModInitializer {
    public static boolean hitSound = true;
    public static boolean hitEffect = true;
    public static boolean customHitboxes = false;
    public static double hitboxExpansion = 0.0;

    private static KeyBinding openMenu;
    private static KeyBinding increaseHitbox;
    private static KeyBinding decreaseHitbox;

    @Override
    public void onInitializeClient() {
        openMenu = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.kipvisuals.open_menu", InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT, "category.kipvisuals"));
        increaseHitbox = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.kipvisuals.increase_hitbox", InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_UP, "category.kipvisuals"));
        decreaseHitbox = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.kipvisuals.decrease_hitbox", InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_DOWN, "category.kipvisuals"));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openMenu.wasPressed()) {
                if (client.currentScreen == null) client.setScreen(new KipVisualsScreen());
                else if (client.currentScreen instanceof KipVisualsScreen) client.setScreen(null);
            }
            while (increaseHitbox.wasPressed()) {
                hitboxExpansion = Math.min(2.0, hitboxExpansion + 0.1);
                if (client.player != null) client.player.sendMessage(
                        Text.literal("Kip Visuals: hitbox + " + String.format("%.1f", hitboxExpansion)), true);
            }
            while (decreaseHitbox.wasPressed()) {
                hitboxExpansion = Math.max(0.0, hitboxExpansion - 0.1);
                if (client.player != null) client.player.sendMessage(
                        Text.literal("Kip Visuals: hitbox + " + String.format("%.1f", hitboxExpansion)), true);
            }
        });

        // Client-side attack feedback. This runs when an attack is initiated;
        // it cannot confirm that the server accepted a hit.
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
            if (world.isClient && MinecraftClient.getInstance().player != null) {
                MinecraftClient client = MinecraftClient.getInstance();
                if (hitSound) client.player.playSound(SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, 0.65f, 1.7f);
                if (hitEffect && client.world != null) {
                    for (int i = 0; i < 8; i++) {
                        double ox = (client.world.random.nextDouble() - 0.5) * 0.5;
                        double oy = client.world.random.nextDouble() * 0.8;
                        double oz = (client.world.random.nextDouble() - 0.5) * 0.5;
                        client.world.addParticle(ParticleTypes.CRIT,
                                entity.getX() + ox, entity.getY() + oy, entity.getZ() + oz,
                                0.0, 0.04, 0.0);
                    }
                }
            }
            return ActionResult.PASS;
        });
    }
}
